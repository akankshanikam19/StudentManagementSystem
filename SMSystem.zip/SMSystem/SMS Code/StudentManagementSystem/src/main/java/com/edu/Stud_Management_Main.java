package com.edu;

import java.util.Scanner;

public class Stud_Management_Main{
	public static void main(String[] args) throws Exception {	
		int  i,ch,c;
		Scanner sc= new Scanner(System.in);
		System.out.println("*-*-*-*-*-*-Welcome to Student Management System-*-*-*-*-*-*-*");
	while(true)
	{
		System.out.println("Enter Your Choice to perform below operations Please!!!");
		System.out.println("1.Admin");
		System.out.println("2.Student");
		ch=sc.nextInt();
		switch(ch)
		{
		case 1:
			while(true)
			{
				System.out.println("Welcome Admin!!!");
				System.out.println("What Operation do you want to perform");
				System.out.println("1.Add Record");
				System.out.println("2.Update Record");
				System.out.println("3.Delete Record");
				System.out.println("4.Show Records");
				 int ch1=sc.nextInt();
				 
				switch(ch1)
				{
				case 1:
					System.out.println("Adding Data");
					 		AdminOperations.add();
					 		break;
					 			
					 case 2: 
					System.out.println("Updating Data");
					 			AdminOperations.update();
					 			break;
					 case 3: 
					System.out.println("Deleting Data");
					 			AdminOperations.delete();	
					 			break;
					 			
					 case 4: 
					System.out.println("Show Student's Data");
								StudentOperations.show();
								break;
				}
				System.out.println("Admin do want to continue press any other key yes...'n' to no");
				char choice=sc.next().charAt(0);
				if(choice=='n')
				{
					break;
				}
			}
			break;
			
		case 2 :
			
			while(true)
			{
				System.out.println("Welcome Student!!!");
				System.out.println("1.View your Data");
					int ch1=sc.nextInt();
				switch(ch1)
				{
				case 1: System.out.println("Given Record are...");
				StudentOperations.show();
				}
//				System.out.println("Do you want to perform any opertaions press enter y for continue and any other key for no");
//				char choice=sc.next().charAt(0);
//				if(choice=='n')
				{
			
		break;
				}
		}
    System.out.println("Do you want to perform any opertaions press enter y for continue and any other key for no");
	char choice=sc.next().charAt(0);
	if(choice=='n')
	{
		break;
	}
	System.out.println("Thank You!!!");
	}
		
	}
}
	}
