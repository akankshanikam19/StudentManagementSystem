package com.edu;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class AdminOperations {
	int Stud_id;
	String Stud_name;
	long Stud_contact;
	String Stud_dept; 
	String Stud_DOB;
	float Stud_fees;
	int Stud_age;
	String Address;
	String Gender;
	static Connection conn;
	
	

	public static void show() throws Exception {
		
		conn=database_Connection.getConnection();
		Statement st=conn.createStatement();
		
		String s="select * from student_management.Student";
		ResultSet rs=st.executeQuery(s);
		
System.out.println("Sid\tSname\tScont\tSdept\tSDOB\tSfees\tSage\tAddress\tGender\tCourse");
		
		while(rs.next()) {
	System.out.println(rs.getInt("Stud_id")+"\t"+rs.getString("Stud_name")
	+"\t"+rs.getInt("Stud_contact")+"\t"+""+rs.getString("Stud_dept")+
	"\t"+""+rs.getFloat("Stud_fees")+"\t"+rs.getInt("Stud_age")+"\t"+
	rs.getString("Address")+"\t"+rs.getString("Gender")+rs.getString("Course"));
		}
	}


	public static void add() throws Exception {
		int Stud_id,Stud_age;
		String Stud_name;
		String Stud_contact; 
		String Stud_dept,Stud_DOB,Address ;
		float Stud_fees;
		String Gender;
		String Course;
		
		conn=database_Connection.getConnection();
		Statement stmt=conn.createStatement();
		
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter Student id to insert");
		Stud_id = sc.nextInt();
		String sel="select * from student_management.Student where Stud_id="+Stud_id;
		
		ResultSet rs=stmt.executeQuery(sel);
		if(!rs.next()) {
//			
//			System.out.println("Enter Student's Id");
//			Stud_id=sc.nextInt();
			
			System.out.println("Enter name of a Student:");
			Stud_name=sc.next();
			
			System.out.println("Enter Student's Mobile Number");
			Stud_contact=sc.next();
			
			System.out.println("Enter Student's Department");
			Stud_dept=sc.next();
			
			System.out.println("Enter Student's dob(yyyy-mm-dd)");
			Stud_DOB = sc.next();
			 
			System.out.println("Enter Student's fees");
			Stud_fees=sc.nextFloat();
			
			System.out.println("Enter Student's age");
			Stud_age=sc.nextInt();
			
			System.out.println("Enter Student's Address");
			Address=sc.next();

			System.out.println("Gender");
			Gender=sc.next();
				
			System.out.println("Enter Course want to Enroll");
			Course=sc.next();
	
			
	String insert="insert into Student values("
			+Stud_id+",'"+Stud_name+"','"+Stud_contact
			+"','"+Stud_dept+"','"+Stud_DOB+"',"+Stud_fees+","
			+Stud_age+",'"+Address+"','"+Gender+"','"+Course+"')";
			System.out.println(insert);
	
			
			int i=stmt.executeUpdate(insert);
			
			if(i>0) {
				System.out.println("Student added successfully");
			}
			
		}else {
			System.out.println(Stud_id+" already exists");
		
		}
	}

	public static void update() throws Exception {
		
		conn=database_Connection.getConnection();
		Statement st=conn.createStatement();
    	   
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Student id to update record");
		int Stud_id = sc.nextInt();
		String sel="select * from student_management.Student where Stud_id="+Stud_id;
		
		ResultSet rs=st.executeQuery(sel);
		if(rs.next()) {  //if employee id exists then go for update
			//switch case
			while(true) {
			System.out.println("Which field he wants to update");
			System.out.println("1. update name");
			System.out.println("2. update Contact Number");
			System.out.println("3. update Department");
			System.out.println("4. update DOB ");
			System.out.println("5. update fees ");					
			System.out.println("6. update Age ");
			System.out.println("7. update Address");
			System.out.println("8. update Gender");
			System.out.println("9. update Course");


			
			int ch=sc.nextInt();
			String upd;
			switch(ch) {
		     //to change name
		case 1: System.out.println("Enter name to change");
		        String sn=sc.next();
		      upd="update student_management.Student set Stud_name='"+sn+"' where Stud_id="+Stud_id;
		      int i=st.executeUpdate(upd);
		        if( i>0) {
		        	System.out.println("Name is changed successfully");
		        }
		        else {
		        	System.out.println("Error occured");
		        }
		        break;
		       //change contact number 
		case 2: System.out.println("Enter Contact number to change");
		String sco=sc.next();
		upd="update student_management.Student set Stud_contact='"+sco+"' where Stud_id="+Stud_id;
		 i=st.executeUpdate(upd);
		 if( i>0) {
			 System.out.println("Contact changed successfully");
		 }
		 else {
			 System.out.println("Error occured");
		 }
		 break;
			       //change department 
		case 3: System.out.println("Enter Depratment to change");
		String sd=sc.next();
		upd="update student_management.Student set Stud_dept='"+sd+"' where Stud_id="+Stud_id;
		 i=st.executeUpdate(upd);
		 if( i>0) {
			 System.out.println("Department updated successfully");
		 }
		 else {
			 System.out.println("Error occured");
		 }
		 break;               
		 //change  date of birth
		case 4: System.out.println("Enter DOB you want to change");
		 String sdob=sc.next();
	      upd="update student_management.Student set Stud_DOB='"+sdob+"' where Stud_id="+Stud_id;
	       i=st.executeUpdate(upd);
	        if(i>0) {
	        	System.out.println("Date of birth is changed successfully");
	        }
	        else {
	        	System.out.println("Error occured");
	        }
	        break;
	        // change fees
		case 5: System.out.println("Enter to Update Fees");
		int sf=sc.nextInt();
		 upd="update student_management.Student set Stud_fees='"+sf+"' where Stud_id="+Stud_id;
	       i=st.executeUpdate(upd);
	        if( i>0) {
	        	System.out.println("fees updated successfully");
	        }
	        else {
	        	System.out.println("Error occured");
	        }
	        break;
	        //update age
		case 6: System.out.println("Enter to Update Age");
		int age=sc.nextInt();
		 upd="update student_management.Student set Stud_age='"+age+"' where Stud_id="+Stud_id;
	       i=st.executeUpdate(upd);
	        if( i>0) {
	        	System.out.println(" Age updated successfully");
	        }
	        else {
	        	System.out.println("Error occured");
	        }
	        break;
	        // change address
		case 7: System.out.println("Enter to Update Address");
		 String add=sc.next();
	      upd="update student_management.Student set Address='"+add+"' where Stud_id="+Stud_id;
	       i=st.executeUpdate(upd);
	        if(i>0) {
	        	System.out.println("Address is updated successfully");
	        }
	        else {
	        	System.out.println("Error occured");
	        }
	        break;
	        //change gender
		case 8: System.out.println("Enter Gender to update");
		 String g=sc.next();
	      upd="update student_management.Student set Gender='"+g+"' where Stud_id="+Stud_id;
	       i=st.executeUpdate(upd);
	        if(i>0) {
	        	System.out.println("Gender changed successfully");
	        }
	        else {
	        	System.out.println("Error occured");
	        }
	        break;
	        // update course
		case 9: System.out.println("Enter the course you want to Enroll");
		 String c=sc.next();
	      upd="update student_management.Student set Course='"+c+"' where Stud_id="+Stud_id;
	       i=st.executeUpdate(upd);
	        if(i>0) {
	        	System.out.println("Course Enrolled successfully");
	        }
	        else {
	        	System.out.println("Error occured");
	        }
	        break;
		
		
		default:System.out.println("Invalid input");
		}
		
		System.out.println("do you want to continue press n to exit any key to continue");
		char choice=sc.next().charAt(0);
		if(choice=='n') {
			break;
		}
		}//while
		System.out.println("Program is terminated");
		System.out.println("Thank You!!!");
	}

}

public static void delete() throws Exception {
	
	conn=database_Connection.getConnection();
	Statement st=conn.createStatement();

	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Student id to delete record");
	int Stud_id=sc.nextInt();
	
	String sql="select * from student_management.Student where Stud_id="+Stud_id;
	ResultSet rs=st.executeQuery(sql);
	
	if(rs.next()) {
		//if record exists in the table go for delete
		String del="delete from student_management.Student where Stud_id="+Stud_id;
		int i=st.executeUpdate(del);
		if(i>0) {
			System.out.println("Student record is deleted");
		}
	}else {
		System.out.println(Stud_id+" Student with given id not exists");
	}

}
	

}


