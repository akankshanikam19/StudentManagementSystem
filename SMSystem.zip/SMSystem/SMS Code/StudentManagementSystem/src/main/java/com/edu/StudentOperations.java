package com.edu;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class StudentOperations {
	long Stud_id;
	String Stud_name;
	long Stud_contact;
	String Stud_dept; 
	String Stud_DOB;
	float Stud_fees;
	int Stud_age;
	String Address;
	String Gender;

	static Connection conn;
	public static void show() throws Exception {
		
		conn=database_Connection.getConnection();
		Statement st=conn.createStatement();
		
		String s="select * from student_management.Student";
		ResultSet rs=st.executeQuery(s);
		
System.out.println(
	"Sid\tSname\tScont\tSdept\tSDOB\tSfees\tSage\tAddress\tGender\tCourse");
		
		while(rs.next()) {
	System.out.println(rs.getInt("Stud_id")+"\t"+rs.getString("Stud_name")
	+"\t"+rs.getInt("Stud_contact")+"\t"+rs.getString("Stud_dept")+
	rs.getString("Stud_DOB")+"\t"+""+rs.getFloat("Stud_fees")+"\t"+
	rs.getInt("Stud_age")+"\t"+rs.getString("Address")+"\t"+
	rs.getString("Gender")+"\t"+rs.getString("Course"));
		
		}
	}
}
