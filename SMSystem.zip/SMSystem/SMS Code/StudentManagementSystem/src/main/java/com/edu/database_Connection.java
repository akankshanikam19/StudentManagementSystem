package com.edu;
import java.sql.*;

public class database_Connection {
	//load the driver
	
public static String driver="com.mysql.cj.jdbc.Driver";
public static String url="jdbc:mysql://localhost:3306/student_management";
public static String un="root";
public static String up="Akanksha@1906";
public static Connection conn;

public static  Connection getConnection() throws Exception {
	
		Class.forName(driver);
conn= DriverManager.getConnection(url,un,up);
	if(conn==null) {
		System.out.println("Error");
	}
	return conn ;
}
}

	
